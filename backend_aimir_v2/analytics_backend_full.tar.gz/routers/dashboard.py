# routers/dashboard.py
from requests import RequestException
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Header, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from db import get_db
from models.user import User
from models.document import Document
from models.contract_analysis import ContractAnalysis
from models.billing_transaction import BillingTransaction
from core.security import decode_token
from core.dashboard_access import get_dashboard_whitelist
from core.config import settings
from core.user_stats import get_cost_for_tokens  # считает стоимость токенов в РУБЛЯХ
from core.yandex_metrika import fetch_visits_timeseries, fetch_goals_funnel
router = APIRouter(prefix="/dashboard", tags=["dashboard"])


# --------- общая auth-обвязка для дашборда ---------


def get_current_user(
    authorization: str = Header(None),
    db: Session = Depends(get_db),
) -> User:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Bearer token",
        )

    token = authorization.split(" ", 1)[1]
    payload = decode_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
        )

    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    return user


# --------- основной дашборд (подписки + выручка по состоянию) ---------


@router.get("", status_code=status.HTTP_200_OK)
def dashboard_data(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Реальные данные для главного дашборда.

    Доступ:
        - только для email'ов из whitelist (core/dashboard_whitelist.json)

    Возвращает:
        - subscriptions.by_type: распределение пользователей по типам подписок
        - subscriptions.total_users: общее количество пользователей
        - revenue.by_type: оценочная выручка по активным подпискам (РУБЛИ)
        - revenue.total_subscriptions: суммарная выручка по подпискам (РУБЛИ)
        - revenue.balance_total: суммарные оплаты за кредиты (разовые запросы, РУБЛИ)
        - revenue.grand_total_estimated: подписки + кредиты (РУБЛИ)
    """
    whitelist = get_dashboard_whitelist()
    if current_user.email.lower() not in whitelist:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )

    users = db.query(User).all()

    counts = {
        "month": 0,
        "six_months": 0,
        "year": 0,
        "other": 0,         # подписка есть, но срок странный
        "balance_only": 0,  # без активной подписки, но есть кредиты (по balance)
        "none": 0,          # ни подписки, ни кредитов
    }

    today = date.today()

    for u in users:
        # активная подписка?
        has_active_sub = (
            bool(u.has_subscription)
            and u.subscription_start is not None
            and u.subscription_end is not None
            and u.subscription_end >= today
        )

        if has_active_sub:
            delta_days = (u.subscription_end - u.subscription_start).days

            if 25 <= delta_days <= 40:
                key = "month"
            elif 150 <= delta_days <= 210:
                key = "six_months"
            elif 350 <= delta_days <= 380:
                key = "year"
            else:
                key = "other"

            counts[key] += 1
        else:
            # нет активной подписки → классифицируем по наличию кредитов (balance > 0)
            if u.balance is not None and Decimal(u.balance) > 0:
                counts["balance_only"] += 1
            else:
                counts["none"] += 1

    total_users = len(users)

    # цены тарифов в РУБЛЯХ
    price_month = Decimal(settings.SUB_PRICE_MONTH)
    price_6m = Decimal(settings.SUB_PRICE_6M)
    price_year = Decimal(settings.SUB_PRICE_YEAR)

    revenue_by_type = {
        "month": price_month * counts["month"],
        "six_months": price_6m * counts["six_months"],
        "year": price_year * counts["year"],
    }

    total_subscriptions_revenue = sum(revenue_by_type.values())

    # суммарная выручка по кредитам из таблицы транзакций (kind = 'credits')
    credits_total_rub_raw = (
        db.query(func.coalesce(func.sum(BillingTransaction.amount_rub), 0))
        .filter(BillingTransaction.kind == "credits")
        .scalar()
    )
    credits_total_rub: Decimal = Decimal(credits_total_rub_raw or 0)

    # общий итог: подписки + кредиты
    grand_total_estimated = total_subscriptions_revenue + credits_total_rub

    def d2f(x: Decimal) -> float:
        return float(x.quantize(Decimal("0.01")))

    return {
        "subscriptions": {
            "by_type": counts,
            "total_users": total_users,
        },
        "revenue": {
            "by_type": {
                "month": d2f(revenue_by_type["month"]),
                "six_months": d2f(revenue_by_type["six_months"]),
                "year": d2f(revenue_by_type["year"]),
            },
            "total_subscriptions": d2f(total_subscriptions_revenue),
            # ВСЕ деньги, уплаченные за кредиты (разовые запросы)
            "balance_total": d2f(credits_total_rub),
            "grand_total_estimated": d2f(grand_total_estimated),
        },
    }


# --------- сводка по пользователям (для модального окна) ---------


@router.get("/users/summary", status_code=status.HTTP_200_OK)
def dashboard_users_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Сводка по всем пользователям, у которых есть хотя бы один документ (не гости).

    Для каждого пользователя возвращаем:
        - id, email, name
        - documents_count        — количество загруженных им документов
        - tokens_total           — суммарные токены по анализам
        - cost_tokens_rub        — наши расходы на токены (РУБЛИ)
        - subscription.type      — тип подписки (month / six_months / year / other / none)
        - subscription.is_active — активна ли подписка сейчас
        - subscription.revenue_rub — выручка по его подписке (РУБЛИ)
        - money_total_rub        — net: подписка − стоимость токенов (РУБЛИ)
    """
    whitelist = get_dashboard_whitelist()
    if current_user.email.lower() not in whitelist:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )

    # subquery: сколько документов у каждого user_id
    docs_subq = (
        db.query(
            Document.user_id.label("user_id"),
            func.count(Document.id).label("docs_count"),
        )
        .group_by(Document.user_id)
        .subquery()
    )

    # subquery: суммарные токены по анализам
    tokens_subq = (
        db.query(
            ContractAnalysis.user_id.label("user_id"),
            func.coalesce(func.sum(ContractAnalysis.tokens_total), 0).label("tokens_total"),
        )
        .group_by(ContractAnalysis.user_id)
        .subquery()
    )

    # берём только тех юзеров, у кого есть хотя бы один документ
    rows = (
        db.query(
            User,
            docs_subq.c.docs_count,
            func.coalesce(tokens_subq.c.tokens_total, 0).label("tokens_total"),
        )
        .join(docs_subq, docs_subq.c.user_id == User.id)
        .outerjoin(tokens_subq, tokens_subq.c.user_id == User.id)
        .all()
    )

    today = date.today()
    items = []

    for user, docs_count, tokens_total in rows:
        docs_count = int(docs_count or 0)
        tokens_total = int(tokens_total or 0)

        # наши расходы на токены (РУБЛИ)
        cost_tokens: Decimal = get_cost_for_tokens(tokens_total)

        # подписка
        has_active_sub = (
            bool(user.has_subscription)
            and user.subscription_start is not None
            and user.subscription_end is not None
            and user.subscription_end >= today
        )

        sub_type = "none"
        sub_revenue: Decimal = Decimal("0")

        if has_active_sub:
            delta_days = (user.subscription_end - user.subscription_start).days

            if 25 <= delta_days <= 40:
                sub_type = "month"
                sub_revenue = Decimal(settings.SUB_PRICE_MONTH)
            elif 150 <= delta_days <= 210:
                sub_type = "six_months"
                sub_revenue = Decimal(settings.SUB_PRICE_6M)
            elif 350 <= delta_days <= 380:
                sub_type = "year"
                sub_revenue = Decimal(settings.SUB_PRICE_YEAR)
            else:
                sub_type = "other"
                # при желании здесь можно задать отдельную цену для кастомных подписок

        # net: сколько он нам принёс от подписки минус расходы на токены
        money_total_rub: Decimal = sub_revenue - cost_tokens

        def d2f(x: Decimal) -> float:
            return float(x.quantize(Decimal("0.01")))

        items.append(
            {
                "id": str(user.id),
                "email": user.email,
                "name": user.name,
                "documents_count": docs_count,
                "tokens_total": tokens_total,
                "cost_tokens_rub": d2f(cost_tokens),
                "subscription": {
                    "type": sub_type,
                    "is_active": has_active_sub,
                    "revenue_rub": d2f(sub_revenue),
                },
                "money_total_rub": d2f(money_total_rub),
            }
        )

    return {"items": items}


# --------- выручка по транзакциям (по периодам, для графиков) ---------


@router.get("/revenue/timeseries", status_code=status.HTTP_200_OK)
def revenue_timeseries(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    start_date: date | None = None,
    end_date: date | None = None,
    group_by: str = "day",  # "day" или "month"
):
    """
    Фактическая выручка по транзакциям (billing_transactions).

    Параметры:
      - start_date / end_date (date, опционально)
          по умолчанию: последние 30 дней
      - group_by: "day" или "month"

    Возвращает:
      - start_date, end_date, group_by
      - items: список точек:
          {
            "bucket": "YYYY-MM-DD" (день или первый день месяца),
            "kind": "subscription" | "credits",
            "amount_rub": float
          }
      - totals:
          {
            "by_kind": { "subscription": ..., "credits": ... },
            "grand_total": ...
          }
    """
    whitelist = get_dashboard_whitelist()
    if current_user.email.lower() not in whitelist:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )

    if group_by not in ("day", "month"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="group_by must be 'day' or 'month'",
        )

    today = date.today()
    if end_date is None:
        end_date = today
    if start_date is None:
        start_date = end_date - timedelta(days=30)

    # включительно по end_date → фильтруем < end_date + 1 день
    from_dt = start_date
    to_dt = end_date + timedelta(days=1)

    trunc_unit = "day" if group_by == "day" else "month"

    # агрегируем по bucket (день/месяц) и виду транзакции
    q = (
        db.query(
            func.date_trunc(trunc_unit, BillingTransaction.created_at).label("bucket"),
            BillingTransaction.kind.label("kind"),
            func.sum(BillingTransaction.amount_rub).label("amount_rub"),
        )
        .filter(BillingTransaction.created_at >= from_dt)
        .filter(BillingTransaction.created_at < to_dt)
        .group_by("bucket", BillingTransaction.kind)
        .order_by("bucket", BillingTransaction.kind)
    )

    rows = q.all()

    def d2f(x) -> float:
        return float(Decimal(x or 0).quantize(Decimal("0.01")))

    items = []
    for r in rows:
        # r.bucket — datetime
        bucket_date = r.bucket.date()
        if group_by == "month":
            # нормализуем к первому числу месяца
            bucket_date = bucket_date.replace(day=1)

        items.append(
            {
                "bucket": bucket_date.isoformat(),
                "kind": r.kind,
                "amount_rub": d2f(r.amount_rub),
            }
        )

    # Итоги за период по видам
    totals_rows = (
        db.query(
            BillingTransaction.kind.label("kind"),
            func.sum(BillingTransaction.amount_rub).label("amount_rub"),
        )
        .filter(BillingTransaction.created_at >= from_dt)
        .filter(BillingTransaction.created_at < to_dt)
        .group_by(BillingTransaction.kind)
        .all()
    )

    totals_by_kind: dict[str, float] = {}
    grand_total = Decimal("0")

    for t in totals_rows:
        amt = Decimal(t.amount_rub or 0)
        totals_by_kind[t.kind] = d2f(amt)
        grand_total += amt

    return {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "group_by": group_by,
        "items": items,
        "totals": {
            "by_kind": totals_by_kind,
            "grand_total": d2f(grand_total),
        },
    }

@router.get("/metrika", status_code=status.HTTP_200_OK)
def dashboard_metrika(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),  # db оставим, чтобы сигнатура была как у других
    start_date: date | None = None,
    end_date: date | None = None,
):
    """
    Данные Яндекс.Метрики для дашборда:
      - visits_timeseries: [{ date, visits }]
      - funnel: { visits_total, steps: [...] }
    """
    whitelist = get_dashboard_whitelist()
    if current_user.email.lower() not in whitelist:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )

    today = date.today()
    if end_date is None:
        end_date = today
    if start_date is None:
        start_date = end_date - timedelta(days=30)

    if start_date > end_date:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="start_date must be <= end_date",
        )

    try:
        visits_ts = fetch_visits_timeseries(start_date=start_date, end_date=end_date)
        funnel = fetch_goals_funnel(start_date=start_date, end_date=end_date)
    except RequestException as e:
        # ошибки сети / HTTP от Яндекса
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Ошибка при запросе к Яндекс.Метрике: {e}",
        )
    except Exception as e:
        # любая другая наша ошибка
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Внутренняя ошибка дашборда Метрики: {e}",
        )

    return {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "visits_timeseries": visits_ts,
        "funnel": funnel,
    }